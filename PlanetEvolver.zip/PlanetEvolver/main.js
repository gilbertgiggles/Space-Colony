
var Width = window.innerWidth;
var Height = window.innerHeight;
var ScaleFactor = (Width / 800) / 2 + (Height / 600) / 2; // How big everything needs to be!
var version = 'alpha1';
var SaveTo = 'SMEntertainmentPlanetEvolver' + version;
var SaveLoaded = false;

var TopNoteId = 0;
var Notes = [];
var IsInGui = true;
var CurrentGui = TestGui;

var c = document.getElementById("canvas");
var ctx = c.getContext("2d");

var db = openDatabase(SaveTo + ".db", '1.0', "PlanetEvolver Save Data!", 1024 * 1024 * 1024);

// =====================
// General Functions
// =====================

/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/

var Base64 = {

    // private property
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

    // public method for encoding
    encode: function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        input = Base64._utf8_encode(input);

        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output +
                this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
                this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

        }

        return output;
    },

    // public method for decoding
    decode: function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },

    // private method for UTF-8 encoding
    _utf8_encode: function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },

    // private method for UTF-8 decoding
    _utf8_decode: function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while (i < utftext.length) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}

function utf8_to_b64(str) {
    try { return Base64.encode(unescape(encodeURIComponent(str))); }
    catch (err)
    { return ''; }
}

function b64_to_utf8(str) {
    try { return decodeURIComponent(escape(Base64.decode(str))); }
    catch (err)
    { return ''; }
}

function roundTo(number, decimals) {
    return (Number(number) + 1 / Math.pow(10, Number(decimals) + 1)).toFixed(decimals);
}

function Beautify(number, short) {
    var toReturn = number.toString();
    var currentNumber = 0;
    var cutOffDigits = 1;
    var everyThree;

    if (short)
        everyThree = [
            '',
            ' M',
            ' B',
            ' T',
            ' Qa',
            ' Qi',
            ' Sx',
            ' Sp',
            ' Oc',
            ' No',
            ' Dc',
            ' UnD',
            ' DoD',
            ' TrD',
            ' QaD',
            ' QiD'
        ];
    else
        everyThree = [
            '',
            ' million',
            ' billion',
            ' trillion',
            ' quadrillion',
            ' quintillion',
            ' sextillion',
            ' septillion',
            ' octillion',
            ' nonillion',
            ' decillion',
            ' undecillion',
            ' duodecillion',
            ' tredecillion',
            ' quattuordecillion',
            ' quindecillion'
        ];

    if (number >= 1000000) currentNumber = 1; // million
    if (number >= 1000000000) currentNumber = 2; // billion
    if (number >= 1000000000000) currentNumber = 3; // trillion
    if (number >= 1000000000000000) currentNumber = 4; // quadrillion
    if (number >= 1000000000000000000) currentNumber = 5; // quintillion
    if (number >= 1000000000000000000000) currentNumber = 6; // sextillion
    if (number >= 1000000000000000000000000) currentNumber = 7; // septillion
    if (number >= 1000000000000000000000000000) currentNumber = 8; // octillion
    if (number >= 1000000000000000000000000000000) currentNumber = 9; // nonillion
    if (number >= 1000000000000000000000000000000000) currentNumber = 10; // decillion
    if (number >= 1000000000000000000000000000000000000) currentNumber = 11; // undecillion
    if (number >= 1000000000000000000000000000000000000000) currentNumber = 12; // duodecillion
    if (number >= 1000000000000000000000000000000000000000000) currentNumber = 13; // tredecillion
    if (number >= 1000000000000000000000000000000000000000000000) currentNumber = 14; // quattuordecillion
    if (number >= 1000000000000000000000000000000000000000000000000) currentNumber = 15; // quindecillion
    if (number >= 1000000000000000000000000000000000000000000000000000) currentNumber = 16; // Infinite?!?!?!

    if (currentNumber !== 16) { // If it does it will literally just show "infinite"
        if (number >= 1000000) {
            var numberToCutOff = "1000000";
            for (var i2 = 1; i2 < currentNumber; i2++) { // Get how many zeros to add then add them!
                numberToCutOff += "000";
            }
            cutOffDigits = parseInt(numberToCutOff);
        }

        // Now, get the first number!

        var firstNumber = number / cutOffDigits;

        // Split the number every 3s with a ","

        //var output = firstNumber.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        var oldNumberBeforeDot = firstNumber.toString().split('.')[0];
        var oldFNumber = oldNumberBeforeDot.split('').reverse().join('');
        var newFNumber = "";
        var isThird = 0;

        for (var i = 0; i < oldFNumber.length; i++) {

            if (isThird >= 3) {
                newFNumber = "," + newFNumber;
                isThird = 0;
            }

            if (oldFNumber[i] === ".") {
                break;
            }

            newFNumber = oldFNumber[i] + newFNumber;
            isThird++;
        }

        // Check if the string has a dot!
        var hasDot = (firstNumber.toString().split('.').length > 1);

        if (hasDot) {
            // Round up...
            var rounded = roundTo(firstNumber, 3);

            var final = rounded.toString().split('.')[1];
            newFNumber += "." + final.toString();
        }

        toReturn = newFNumber + everyThree[currentNumber];
    } else toReturn = "Infinite";
    return toReturn;
}

function Within(x1, y1, x2, y2, width, height) {
    if (x2 <= x1 && x1 <= x2 + width && y2 <= y1 && y1 <= y2 + height) return true;
    else return false;
}

function ChangeCursor(hand) {
    if (hand) document.body.style.cursor = "hand";
    else document.body.style.cursor = "default";
}

function OpenGui(gui) {
    CurrentGui = gui;
    IsInGui = true;
    Redraw();
}
// =====================
// Interaction
// =====================

MapPositionSubX = 0;
MapPositionSubY = 0;

window.onkeydown = function (e) {
    if (e.keyCode == 37) { // Left arrow
        if (Game.MapPositionX != 0) {
            if (MapPositionSubX == 0) {
                Game.MapPositionX -= 1;
                MapPositionSubX = 7;
            }
            else MapPositionSubX -= 1;
        }
    } else if (e.keyCode == 38) { // Up arrow
        if (Game.MapPositionY != 0) {
            if (MapPositionSubY == 0) {
                Game.MapPositionY -= 1;
                MapPositionSubY = 7;
            }
            else MapPositionSubY -= 1;
        }
    } else if (e.keyCode == 39) { // Right arrow
        if (Game.MapPositionX != Game.MapWidth - 40) {
            if (MapPositionSubX == 7) {
                Game.MapPositionX += 1;
                MapPositionSubX = 1;
            }
            else MapPositionSubX += 1;
        }
    } else if (e.keyCode == 40) { // Down arrow
        if (Game.MapPositionY != Game.MapHeight - 40) {
            if (MapPositionSubY == 7) {
                Game.MapPositionY += 1;
                MapPositionSubY = 0;
            }
            else MapPositionSubY += 1;
        }
    } else if (e.keyCode == 27) { // Esc
        if (IsInGui) {
            IsInGui = false;
        }
    }
    Redraw();
}

document.onmousemove = function () {
    ChangeCursor(false);

    if (IsInGui) {
        var x = (Width / 2) - (CurrentGui.Width / 2);
        var y = (Height / 2) - (CurrentGui.Height / 2);

        for (var i = 0; i < CurrentGui.Slots.length; i++)
            if (Within(event.x, event.y, CurrentGui.Slots[i].x + x, CurrentGui.Slots[i].y + y, 32, 32)) ChangeCursor(true);       
    } else {
        if (Within(event.x, event.y, Width - (40 * ScaleFactor), Height - (40 * ScaleFactor), 32 * ScaleFactor, 32 * ScaleFactor, 5)) ChangeCursor(true);
    }
}

// =====================
// Drawing
// =====================

function FindMapBlockAtPosition(x, y) {
    return ((Game.MapWidth * (y + 1)) - (Game.MapWidth - (x + 1))) - 1;
}

function Redraw() {
    Width = window.innerWidth;
    Height = window.innerHeight;
    ScaleFactor = ((Width / 800) / 2) + ((Height / 600) / 2);   

    c.width = Width;
    c.height = Height;

    // Draw the map!
    var breaking = false;
    var ix = -1;
    var iy = -1;

    //alert(Height / 32);
    for (var y = Game.MapPositionY; iy < 40; y++) {
        for (var x = Game.MapPositionX; ix < 40; x++) {

            if (y > Game.MapHeight)
                breaking = true;

            var Block = FindBlockById(Game.Map[FindMapBlockAtPosition(x, y)]);

            ctx.drawImage(Block.Image, ix * 32 * ScaleFactor - (MapPositionSubX * ScaleFactor * 4), iy * 32 * ScaleFactor - (MapPositionSubY * ScaleFactor * 4), Block.Width * ScaleFactor, Block.Height * ScaleFactor);

            if (x == Game.MapWidth - 1) {
                y++;
                iy++;
                x = Game.MapPositionX - 1;
                ix = -1; // It increments to 0 next!
            } 

            if (breaking) break;
            ix++;
        }
        iy++;
        x = Game.MapPositionX - 1;
        ix = -1; // It increments to 0 next!
        //alert("Another line!");
        if (breaking) break;
    }

    // Draw the money displayer...
    
    //ctx.drawImage(dollar_icon, Width - 200, 30, 30 * ScaleFactor, 25 * ScaleFactor);

    ctx.globalAlpha = 0.5;
    //ctx.rect(Width - (200 * ScaleFactor), 30 * ScaleFactor, 200 * ScaleFactor, 30 * ScaleFactor);
    //ctx.Stroke();

    ctx.globalAlpha = 1;
    ctx.font = "30px Source Sans Pro";

    ctx.strokeStyle = "rgb(255, 0, 0)";
    ctx.fillStyle = "rgb(0, 0, 0)";
    ctx.globalAlpha = 0.5;

    roundRect(ctx, Width - (40 * ScaleFactor), Height - (40 * ScaleFactor), 32 * ScaleFactor, 32 * ScaleFactor, 5, true, true);
    ctx.globalAlpha = 1;

    ctx.fillText(Game.Money, 10, Height - 150);
    ctx.fillText(Beautify(123523532500000000000000000000000000000000000000000, false), 10, Height - 20);
    ctx.fillText(ScaleFactor, 10, Height - 80);

    if (IsInGui) {
        DrawBlackSheet();

        DrawGui(CurrentGui);
    }
}

function DrawGui(gui) {
    ctx.strokeStyle = "rgb(0, 0, 255)";
    ctx.fillStyle = "rgb(0, 0, 0)";

    var x = (Width / 2) - (gui.Width / 2);
    var y = (Height / 2) - (gui.Height / 2);
    roundRect(ctx, x, y, gui.Width, gui.Height, 5, true, true);

    for (var i = 0; i < gui.Slots.length; i++) {
        roundRect(ctx, gui.Slots[i].x + x, gui.Slots[i].y + y, 32, 32, 5, true, true)
    }
}

function DrawBlackSheet() {
    var oldAlpha = ctx.globalAlpha;
    ctx.globalAlpha = 0.5;
    ctx.fillRect(0, 0, Width, Height);
    ctx.globalAlpha = oldAlpha;
}

function FindBlockById(id) {
    for (var i = 0; i < Blocks.length; i++)
        if (Blocks[i].id == id) return Blocks[i];
}

function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
    if (typeof stroke == 'undefined') {
        stroke = true;
    }
    if (typeof radius === 'undefined') {
        radius = 5;
    }
    if (typeof radius === 'number') {
        radius = { tl: radius, tr: radius, br: radius, bl: radius };
    } else {
        var defaultRadius = { tl: 0, tr: 0, br: 0, bl: 0 };
        for (var side in defaultRadius) {
            radius[side] = radius[side] || defaultRadius[side];
        }
    }
    ctx.beginPath();
    ctx.moveTo(x + radius.tl, y);
    ctx.lineTo(x + width - radius.tr, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr);
    ctx.lineTo(x + width, y + height - radius.br);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height);
    ctx.lineTo(x + radius.bl, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl);
    ctx.lineTo(x, y + radius.tl);
    ctx.quadraticCurveTo(x, y, x + radius.tl, y);
    ctx.closePath();
    if (fill) {
        ctx.fill();
    }
    if (stroke) {
        ctx.stroke();
    }
}


// ====================
// Notifications
// ====================

// The below two functions aren't really notification related but are for the HTML-side of things (like the notifications).

function ShowAndHideContext() {
    if (GetStyleOfContextDropDown() == "none") {      
        document.getElementById('contextDropDown').style.display = "block";
    } else {
        document.getElementById('contextDropDown').style.display = "none";
    }
}

function GetStyleOfContextDropDown() {
    return document.getElementById('contextDropDown').currentStyle ? document.getElementById('contextDropDown').currentStyle.display :
        getComputedStyle(document.getElementById('contextDropDown'), null).display;
}

/*
EXAMPLE NOTIFICATION:
<li class="notification" id="note-1">
                    <div class="notiClose" onclick="CloseNote(1)"></div>
                    <div class="notificationInner">
                        <h1 class="notiHeading"> Hello world! </h1>
                        <div class="notiSplit" />
                        <p class="notiBody"> This is a test notification, please close it using the close button above.</p>
                        <div class="notiSplit" />
                        <p class="notiBody"> "More Info here." </p>
                    </div>
                </li>
*/

function Notify(title, text, image, size, onesecondclose) {
    if (size == undefined) size = 160;
    if (onesecondclose == undefined) onesecondclose = false;

    var htmlAdd = "";
    var topNoteId = GetTopNoteId();
    htmlAdd += '<li class="notification" style="height: ' + size + 'px;" id="note-' + topNoteId + '"><div class="notiClose" onclick="CloseNote(' + topNoteId + ')"></div><div class="notificationInner">';
    if (onesecondclose) setTimeout(() => { CloseNote(topNoteId); }, 1000)
    if (title != null) htmlAdd += '<h1 class="notiHeading">' + title + '</h1>';
    if (image != null) htmlAdd += '<img src="' + image.src + '" class="notiImage" />';
    if (text != null) htmlAdd += '<div class="notiSplit" /><h1 class="notiBody">' + text + '</h1> <div class="notiSplit" />';
    htmlAdd += '</div></li>';
    AddNotification(htmlAdd);
}

function NotifyAdvanced(template, html) {
    var htmlAdd = "";
    var topNoteId = GetTopNoteId();
    htmlAdd += '<li class="notification" id= "note-' + topNoteId + '"><div class="notiClose" onclick="CloseNote(' + topNoteId + ')"></div><div class="notificationInner">';
    if (title != "") htmlAdd += '<h1 class="notiHeading">' + title + '</h1> <div class="notiSplit" />';
    if (image != null) htmlAdd += '<img src="' + image.src + '" class="notiImage" />';
    if (text != "") htmlAdd += '<h1 class="notiBody">' + text + '</h1> <div class="notiSplit" />';
    htmlAdd += '</div></li>';
}

function AddNotification(html) {
    Notes.push(html);
    RefreshNotifications();
}

function RefreshNotifications() {
    if (document.getElementById('notiPanel') != null) document.getElementById('notiPanel').innerHTML = ""; // Clears the notifications
    var toAdd = "";
    if (Notes.length > 3) {
        var amountLeft = (Notes.length - 3);
        // Increment the +X notifications screen.
        toAdd += '<li class="notificationTiny"> <h1 class="notiHeading" style="transform: translate(8px, 10px);"> +' + amountLeft + ' more notifications </h1> </li>';
    }

    var newNotes = Notes.reverse();
    for (var i = 0; i < newNotes.length; i++)
        if (i < 3) toAdd += newNotes[i];

    if (document.getElementById('notiPanel')) document.getElementById('notiPanel').innerHTML = toAdd;
}

function GetTopNoteId() {
    return TopNoteId++;
}

function CloseNote(index) {
    var currentNotes = document.getElementById('notiPanel').childNodes;
    for (var i = 0; i < Notes.length; i++) {

        if (Notes[i].indexOf('id="note-' + index + '"') !== -1) {
            // This is the note we need to close
            Notes.splice(i, 1);
        }
    }
    RefreshNotifications();
}

document.body.onresize = function () {
    Redraw();
    Notify("Resized!", null, null);
}

setInterval(() => { Redraw(); }, 1000);