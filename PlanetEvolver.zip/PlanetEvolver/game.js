// ==========
// Game Variables
// ==========

var Game = {};
Game.Map = [];
Game.TopMap = [];
Game.MapWidth = 0;
Game.MapHeight = 0;
Game.MapPositionX = 0;
Game.MapPositionY = 0;
Game.Money = 0;

// Debug Code - The code below is for testing purposes pretty much only!

Game.MapWidth = 2000;
Game.MapHeight = 2000;

//Game.Map = Array.from({ length: Game.MapWidth * Game.MapHeight }, () => Math.floor(Math.random() * 2)); //A random map that is 200x200 // [0, 0, 0, 1, 1, 1, 0, 1] 
//
//Game.Map = [0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1];

Game.MapPositionX = 30;
Game.MapPositionY = 30;

// =====================
// SaveSystem
// =====================
Game.NewGame = function () {
    Game.Map = Array.from({ length: Game.MapWidth * Game.MapHeight }, () => Math.floor(Math.random() * 2));
    Game.TopMap = Array.from({ length: Game.MapWidth * Game.MapHeight }, () => Math.floor(Math.random() * 2)); //A map that is 200x200 above the original map! // [0, 0, 0, 1, 1, 1, 0, 1] 
    SaveLoaded = true;
    Game.Save();
};

Game.SaveData = function () {
    var data = "";
    // Header:
    data += version + "|";

    // Main data:
    data += Game.Money.toString() + "|";
    data += Game.MapWidth.toString() + "|";
    data += Game.MapHeight.toString() + "|";
    data += Game.MapPositionX.toString() + "|";
    data += Game.MapPositionY.toString() + "|";

    // Map?
    for (var i = 0; i < Game.Map.length; i++) {
        data += Game.Map[i];
    }

    data += + "|";
    // TopMap?

    for (var i = 0; i < Game.TopMap.length; i++) {
        data += Game.TopMap[i];
    }

    data += "|";
    return utf8_to_b64(data);   

    
};

Game.Save = function () {
    if (SaveLoaded) {
        var data = Game.SaveData();
        db.transaction(function (tx) {
            tx.executeSql("CREATE TABLE IF NOT EXISTS save (savedata text)");
            tx.executeSql("DELETE FROM save");
            tx.executeSql("INSERT INTO save (savedata) VALUES (?)", [data]);
        });

        Notify("Game Saved!", null, null, 40, true);
    }
}

Game.LoadFromData = function (input) {
    try {
        var dataStr = b64_to_utf8(input);

        // Header:
        var data = dataStr.split("|");

        switch (data[0]) {
            case "alpha1":

                // Main data
                Game.Money = parseInt(data[1]);
                Game.MapWidth = parseInt(data[2]);
                Game.MapHeight = parseInt(data[3]);
                Game.MapPositionX = parseInt(data[4]);
                Game.MapPositionY = parseInt(data[5]);

                // Map?
                Game.Map = [];
                var MapValues = data[6].split('');
                for (var i = 0; i < MapValues.length; i++) {
                    Game.Map.push(parseInt(MapValues[i]));
                }

                // TopMap?
                Game.TopMap = [];
                var TopMapValues = data[7].split('');
                for (var i = 0; i < TopMapValues.length; i++) {
                    Game.TopMap.push(parseInt(TopMapValues[i]));
                }
                break;
        }
        SaveLoaded = true;
    } catch (err) {
        Game.NewGame();
    }
};

Game.Load = function () {
    try {
        db.transaction(function (tx) {
            tx.executeSql("SELECT savedata FROM save", [], function (tx, results) {
                Game.LoadFromData(results.rows[0].savedata);
            });
        });
    } catch (err) {
        Game.NewGame();
    }
};
//var testvar = "1";
//window.localStorage.setItem(SaveTo, testvar);

// The lines below have been moved to main.js due to how the system works.
Game.Load();

Game.Save();

setInterval(() => { Game.Save(); }, 60000)

// Hide that loading screen!

document.body.onload = function () {
    document.getElementById('loadingScreen').style.display = 'none';
    Redraw();
}