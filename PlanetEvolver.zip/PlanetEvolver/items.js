var Blocks = [];
var Guis = [];

var Block = function (id, image, width, height, toponly, verytoponly) {
    this.id = id;
    this.Image = new Image();
    this.Width = width;
    this.Height = height;
    this.toponly = toponly;
    this.verytoponly = verytoponly

    if (this.domain == null) this.Image.src = image;
    else this.Image.src = this.domain + "\\" + image;

    Blocks.push(this);
}

var Gui = function (ItemSlots, width, height) {
    this.Slots = ItemSlots;
    this.Width = width;
    this.Height = height;

    Guis.push(this);
}

var Slot = function (x, y) {
    this.block = null;
    this.Amount = null;
    this.x = x;
    this.y = y;
}
// =====================
// Images - IMPORTANT!
// =====================

//var dirt_img = new Image();
//var stone_img = new Image();

//if (this.domain == null) {
    
//    dirt_img.src = "img\\dirt.png";
//    stone_img.src = "img\\stone.png";
//} else {
    
//    dirt_img.src = this.domain + "\\img\\dirt.png";
//    stone_img.src = this.domain + "\\img\\stone.png";
//}

// =====================
// Blocks
// =====================

var Dirt = new Block(0, "img\\dirt.png", 32, 32, false, false);
var Stone = new Block(1, "img\\stone.png", 32, 32, false, false);

var TestGui = new Gui([new Slot(200, 200)], 400, 300);